<?php
$host="localhost";
$user="id21910285_host";
$pass="Mkori339#";
$dbname="id21910285_mkori";
$con=mysqli_connect($host,$user,$pass,$dbname);
if(!$con){
    echo("not connected.");
}

