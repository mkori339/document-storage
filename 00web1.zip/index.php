<?php
session_start();
 include("connection.php");
 if(isset($_SESSION['id']) ){
    $id=$_SESSION['id'];
 $sql="SELECT *FROM hafidhi WHERE  id='$id'";
 $check=mysqli_query($con,$sql);
 if(mysqli_num_rows($check)>0){
    while($row=mysqli_fetch_assoc($check)){
$year=$row['year'];
$name=$row['name'];
$pass=$row['pasward'];
$id=$row['id'];
$seno=$row['seno'];
    }
 }
 //
 $uploadedBy = $id;
 $sql1 = "UPDATE hafidhi3  SET uploadedBy='$uploadedBy' WHERE seno= '$seno'";
if( mysqli_query($con,$sql1)){
       // print "data inserted in a database correctly";

     }
 else {
    echo "Sorry, there was an error uploading your file.";
}
//header("Refresh:60; url=index.php");

 }
 else
header("location:login.php");
?>
 
 <!DOCTYPE html>
<html>
<head>
  <meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
  <title>hafidhi website</title>
  <style>
   #button6{
    background-color: rgb(255,255,255);
    border: 4px solid yellow;
    width: 150px; height:150px; 
    border-radius: 70px;
    box-shadow: 5px 5px 5px black;
   }
   #file{
    border-radius: 10px;
    background-color: #262626; 
    height: 40px;
   }
  #body1{
  width:98%;
  height:80%;
  margin:auto;
  padding:5px;
background-image:url("kk.jpg");
background-position:center;
background-attachment:fixed;
background-size:cover;
background-repeat:no-repeat;
  }
  #fs1{
 box-shadow: 25px 25px 25px black;
background-image:url("rrr.jpg");
background-position:center;
background-attachment:fixed;
background-size:cover;
background-repeat:no-repeat;
  }
  </style>
	    <link rel="stylesheet" href="srm.css">
        <div  id="div1" style=" box-shadow: 15px 15px 15px black; border-radius: 80px;">
            <button  id="button1"><a href="logout.php" style="box-shadow: 1px 7px 1px grey;background-color: red;"><b>LOGOUT</b></a></button>
            <button  id="button2" style="box-shadow: 1px 7px 1px grey;">MENU</button>
            <center>
            <h1 id="m_para"><i>PORTFOLIO STORAGE SYSYTEM (PRS) <i></h1
                <b><h6 id="m_para"><marquee behavior="scroll" direction="left" loop="-1"scrollamount="3" style="color:grey"><i>MKORI'S TRIAL SYSTEM (MTS) REGISTERD YOU WITH ID <?php echo($id);?> THANKS FOR YOUR SUPPORT AND COPERATION<i></marquee></h6></b>
            </center>
            
        </div><br>
</head>

<body  id="body1" style="background-color:bisque;">
<div style="box-shadow: 15px 15px 15px black;  border-radius: 10px;background-color:grey;border:solid 20px black;height:80%; width: 97%;">
<hr></hr>
<div id="div2" style=" height: 50px; width: 99%;">
<center>
          <button class="button3">OTHERS</button>
            <button class="button3">SPORTS</button>
            <button class="button3">HEALTH</button>
            <button class="button3">CONTRIBUTION</button>
            <button class="button3">ANNOUNCEMENT</button>
            <button class="button3">STUDENT </button>
            <button class="button3">OTHERS</button>
            <button class="button3">OTHERS</button>
            <button class="button3">OTHERS</button>
            <button class="button3">OTHERS</button>
</center>
           
</div><hr><hr/> 
<?php
//session_start();
 include("connection.php");
 if(isset($_SESSION['id']) ){
    $id=$_SESSION['id'];
    //
      $sql = "SELECT * FROM hafidhi3 WHERE uploadedBy = '$id'";
  $result = mysqli_query($con, $sql);
 if (!$result) {
  echo "Query error: " . mysqli_error($con);
} else {

  while ($data = mysqli_fetch_assoc($result)) {
    $_SESSION['profile']=$data['iimagepath'];
      echo "<center >";
      echo "<img  id='button6'  src='./pfile/" . $data['iimagepath'] . "'><br>";
      echo "</center>";
  }
  } } 
      ?>     
         <center>
         <div id="div3"  style="height: 100px;"><P><b><h2  style="color:bisque">LOGED IN AS:  <?php echo($name);?></h2></b></P>
           <P><b><h2   style="color:bisque; box-shadow: 25px 25px 25px black;">WEll COME FOR SUPPORT US:</h2></b></P>
           </div>
<button style="    box-shadow: 25px 25px 5px black; border:solid 4px; border-radius: 20px;background-color:bisque;"><a href="update.php" ><h4>update your details</h4></a></button>
<button style="    box-shadow: 25px 25px 5px black; border:solid 4px; border-radius: 20px; background-color:bisque"><a href="delete.php"><h4>view your document</h4></a></button><br><br><br>


<form method="POST" action="prendex.php" enctype="multipart/form-data">
    <fieldset id="fs1" style="text-align:center;width: 80%;background-color:bisque;border-radius: 10px;">
      <legend style="height:43px; border:solid 4px grey;background-color:grey;border-radius: 35px;"><h3>uplod your document</h3></legend>
      <hr>
    <input type="file" name="file" style=" border-radius: 10px;background-color: #262626; height: 40px;"> 
  <input type="text" placeholder="document title" name="caption" style=" border-radius: 10px;background-color: white; height: 35px;width: 250px;"><br><br>
  <hr>
  <?php
  if( $_SESSION['profile']==""){
    echo"<b>profile picture:</b>";
    echo " <input type='file'id='file' name='file1' >";
    echo"<br>";
    echo"<br>";
  }
  else
  echo " <input type='file' name='file1' value='' hidden >";
  ?>  
<button type="submit" style="height: 33px; background-color: red;border-radius: 5px;"><h7>submit</h7></button>
    </fieldset>
  </form>
  <div style="width: 80%; height:350px;" >
</div>
  </center><br>
  <hr></hr>
<script>
    var page1=document.getElementById("div2");
  button2.addEventListener('click',function(){
       page1.transitionDuration='5';
       page1.style.transition='5'; 
       if(page1.style.display==='none'){
           page1.style.display='block';  }
       else{ page1.style.display='none'; }
  
     }  )
       </script>
</div>
</body>
</html>