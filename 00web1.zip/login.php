<?php
session_start();
  include("connection.php");
  if($_SERVER['REQUEST_METHOD']=="POST")
{ 
  $name=$_POST['name'];
   $pass=$_POST['pass'];
   $sql="SELECT *FROM hafidhi WHERE  name='$name' && pasward='$pass' limit 1";
 $check=mysqli_query($con,$sql);
 if(!$check){
    echo("kkkk");
 }
 if(mysqli_num_rows($check)>0){
    while($row=mysqli_fetch_assoc($check)){
$_SESSION['id']=$row['id'];
if($name=$row['name']&& $pass=$row['pasward']){
    header("location:index.php");
}


  }
   
 }
 mysqli_close($con);



 echo'<script>
 window.alert("wrong user name or password");
  </script>';

}
?>
<!DOCTYPE html>

<html>
<head>
  <meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
  <title>hafidhi website</title>
  <style>
  .div10{
  display: flex;
  justify-content: space-between;
  width:85%
}
.div20{
  height:300px;
  width: 500px;
  border-radius: 10px;
  border: 2px solid black;
  background-color: bisque;
}
#parr:hover{
  opacity: 0.9;
      transition:opacity 0.15s;
      box-shadow: 25px 25px 25px black;
  }
  #container:hover{
  opacity: 1.5;
      transition:opacity 0.15s;
    box-shadow: 25px 25px 25px black;
  }
  #container{
  background-color:rgb(0, 217, 255);
  width:90%;
  height:100%;
border:solid 20px bisque;
background-image:url("rrr.jpg");
background-position:center;
background-attachment:fixed;
background-size:cover;
background-repeat:no-repeat;
border-radius: 50px;
  }
  #container2{
  background-color:rgb(0, 217, 255);
background-image:url("kk.jpg");
background-position:center;
background-attachment:fixed;
background-size:cover;
background-repeat:no-repeat;
  }
  </style>
  <link rel="icon" type="image/x-icon" height="50px" width="50px" href="x.jpeg">
</head>
<body id=container2 ><center>
  <div id=container>
   <h1 style="color:bisque"><i>kindly login into the page</i></h1><br>
   <image src="uu.jpg" style=" border: 4px solid yellow;width: 150px; height:150px; border-radius: 70px;" alt="my picha" border="3px">
   <hr></hr>
  <form method="POST" action="login.php">
    <fieldset style="width: 80%; background-color:bisque;">
      <legend style="background-color:bisque;border-radius: 35px;">person information</legend>
    <input type="text" name="name" placeholder="user name" style="width: 50%; height: 30px;  border-radius: 10px;" required><br>
    <input type="password" name="pass" placeholder="your passward" style="width: 50%; height: 30px;  border-radius: 10px;" required><br><br>
    <button type="submit" style="background-color: red;">Log in</button><br><br>
    <a href="registration.php" style="color: red;"><i>click register</i></a>
    </fieldset>
  </form>
  <hr></hr>
	<hr></hr>
    <div class="div10">
        <div class="div20" id="parr"><video src="v1.mp4"  height="250px" width="84%"  alt="motiation video" controls></video><br>
        <p style="color:blue">kudevela comedy</p>
        </div>
        <div class="div20" id="parr"><video src="v3.mp4"  height="250px" width="84%"  alt="motiation video" controls></video>
        <p style="color:blue">Nasheed nzuri</p>
      </div>
    </div>
    <hr></hr>
    <br>
    <fieldset style="width: 80%; height:300px; background-color:bisque;">
      <legend><div  ><image src="x.jpeg" style=" border: 4px solid yellow;width: 150px; height:150px; border-radius: 60px; background-color: red;"></div></legend>
    <h3 style="color:blue"><i>this website is designed for purpose of tryal by <u style="color:green">hafidhi mkori</u> student at universit of 
  Dodoma. the aim is to store different documents such as pictures,notes,and oether official documents so that to avoid or reduce the problem of  lost it in one way
or another.probably it may have some weakneses that can be caused by sysytem since it is only for tryal.</i></h3>
    </fieldset>
     <hr></hr>
<div style="width: 80%; height:300px;" >
</div>
</div>
</center>
</body>
</html>