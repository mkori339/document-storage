<?php
session_start();
 include("connection.php"); 
 if(isset($_SESSION['id']) ){
    $uploadedBy=$_SESSION['id'];
if($_SERVER['REQUEST_METHOD']=="POST")
{ 
  
  $file1=$_FILES["file1"]["name"];
  $file=$_FILES["file"]["name"];
  $caption=$_POST['caption'];
$targetDir1 ="pfile/";
   $targetDir = "./Hafidhi/";
   

if ($file1!=" ") {
$uploadedFile1 = $_FILES["file1"]["name"]; 
$basename1 = basename($uploadedFile1); 
$targetFile1 = $targetDir1 . $basename1;
$targetFile1 = $targetDir1 . basename($_FILES["file1"]["name"]);
$sql2 = "UPDATE hafidhi3 SET iimagepath= '$basename1' WHERE uploadedBy='$uploadedBy'";
if (move_uploaded_file($_FILES["file1"]["tmp_name"], $targetFile1)) {
   // echo "File uploaded successfully.";

     if( mysqli_query($con,$sql2)){
        print "data inserted in a database correctly";
     }
} else {
   // echo "Sorry, there was an error uploading your file.";
}
}
//
 
    if ( $file!=" "){
    $uploadedFile = $_FILES["file"]["name"]; 
    $basename = basename($uploadedFile); 
    $targetFile = $targetDir . $basename;
    $targetFile = $targetDir . basename($_FILES["file"]["name"]);

    $sql = "INSERT INTO hafidhi2 (caption, imagepath, uploadedBy) VALUES ('$caption', '$basename', '$uploadedBy')";
    if (move_uploaded_file($_FILES["file"]["tmp_name"], $targetFile)) {
        //echo "File uploaded successfully.";

         if( mysqli_query($con,$sql)){
             
        //  echo "data inserted in a database correctly";
         }
    } else {
      //  echo "Sorry, there was an error uploading your file.";
    }
mysqli_close($con);
 header("location:index.php");
die();
 
         
    }
    
 }

}

?>