<?php
session_start();
  include("connection.php");
  if($_SERVER['REQUEST_METHOD']=="POST")
{ 
  $name=$_POST['name'];
  $seno=$_POST['id'];
   $year=$_POST['year'];
   $pass=$_POST['pass'];
//
$sql1 = "INSERT INTO hafidhi3 (seno) VALUE ('$seno')";
if( mysqli_query($con,$sql1)){
       // print "data inserted in a database correctly";
     }
 else {
   // echo "Sorry, there was an error uploading your file.";
}
//
$sql="INSERT INTO hafidhi(seno,name,pasward,year) VALUE('$seno','$name','$pass','$year')";
if(!mysqli_query($con,$sql)){
  echo(" data not inserted");
}
else{
  header("location:login.php");
}
}

?>

<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
  <title>hafidhi website</title>
  <style>
  #container:hover{
  opacity: 0.9;
      transition:opacity 0.15s;
    box-shadow: 25px 25px 25px black;
  }
  #container{
  width:90%;
  height:80%
border:solid 20px bisque;
background-image:url("rrr.jpg");
background-position:center;
background-attachment:fixed;
background-size:cover;
background-repeat:no-repeat;
border-radius: 50px;
  
  }

  #container2{
  background-color:rgb(0, 217, 255);
background-image:url("kk.jpg");
background-position:center;
background-attachment:fixed;
background-size:cover;
background-repeat:no-repeat;
  
  }
  </style>
</head>
<body id=container2><center>
<div id=container>
   <h1>please fill the information below</h1><br>
   <hr></hr>
  <form method="POST" action="registration.php" enctype="multipart/form-data">
    <fieldset style="width: 80%;background-color:bisque;">
      <legend style="background-color:bisque;border-radius: 10px;" ><h2>TAARIFA BINAFSI</h2></legend>
    <input type="text" name="name" placeholder="jina la kwanza" style="width: 50%; height: 30px;  border-radius: 10px;" required><br>
    <input type="password" name="pass" placeholder="weka passward"style="width: 50%; height: 30px;  border-radius: 10px;" required><br>
  <input type="number" name="year" placeholder="mwaka a kuzaliwa" style="width: 50%; height: 30px;  border-radius: 10px;" required><br>
  <input type="number" name="id" placeholder="namba ya nida" style="width: 50%; height: 30px;  border-radius: 10px;" required><br>
   
    </fieldset>
    <fieldset  style="width: 80%;background-color:bisque;"  >
<legend><div style="background-color:bisque;border-radius: 10px;"><b><h2>TAARIFA BINAFSI</h2></b></div></legend>
<lebel>email</lebel>
<input style="width: 50%; height: 30px;  border-radius: 10px;" type="email"id="" name="email" size="40" required><br>
<lebel>phone</lebel>
<input style="width: 50%; height: 30px;  border-radius: 10px;" type="tel"id="phone" name="phone" size="40" required><br>
<lebel>date</lebel>
<input type="date"id="date" name="date" size="40" required><br>
Gender:
<lebel>male</lebel>
<input type="radio"id="gender" name="gender" >
<lebel>female</lebel>
<input type="radio"id="gender" name="gender">
<lebel>others</lebel>
<input type="radio"id="gender" name="gender"><br>
</fieldset>
<fieldset style="width: 80%;background-color:bisque;">
<legend style="background-color:bisque;border-radius: 10px;"><b><h2>MENGINEYO</h2></b></legend>
uraia
<select>
<option>-chagua-</option>
<option>mtanzania</option>
<option>sio mtanzania</option>
</select><br><br>
<b>education level:</b><br>
<bel>diplomer</lebel>
<input type="checkbox"id="jinsi" name="gender"><br>
<bel>degree</lebel>
<input type="checkbox"id="gender" name="gender"><br>
<bel>masters</lebel>
<input type="checkbox"id="gender" name="gender"><br>
</fieldset>
<input type="reset" value="reset">
<button type="submit" style="background-color: red;">submit</button>
  </form>
  <hr></hr>
  <div style="width: 80%; height:300px;" >
</div>
</div></center>
</body>
</html>
