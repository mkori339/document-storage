<?php
session_start();
include("connection.php");
if(isset($_SESSION['id']) ){
  $id=$_SESSION['id'];
  $sql = "SELECT * FROM hafidhi2 WHERE uploadedBy = '$id'";
  $result = mysqli_query($con, $sql);
 if (!$result) {
  echo "Query error: " . mysqli_error($con);
} else {

  while ($data = mysqli_fetch_assoc($result)) {
      echo "<center >";
      echo "<div height='850px'  id='button4' >";
      echo "<i>";
      echo "<b>";
      echo "<h2>";
      echo $data['caption'] . "<h2>";
      echo "</b>";
      echo "</i>";
      echo "<img  id='button5' border='3px' height='700px' width='60%' class='clickable-image' src='./Hafidhi/" . $data['imagepath'] . "'><br>";
      echo "</div>";
      echo "</center>";
  }
}
  if($_SERVER['REQUEST_METHOD']=="POST")
{$idd=$_POST['id']; 
   $sql="DELETE FROM hafidhi2  WHERE uploadedBy='$idd' ";
 $check=mysqli_query($con,$sql);
 if($check){
    
 // echo("sucsessfull");
 }
 else{
    //echo("something went wrong");
}
}
mysqli_close($con);
 }
 else
 header("location:login.php");
?>
<!DOCTYPE html>

<html>
<head>
  <meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
  <title>hafidhi website</title>
  <style>
  #button4{
    border: 4px green;
    background-color:grey;
    border-radius: 15px;
    width: 90%;
    padding-bottom:50px;
    box-shadow: 15px 15px 25px black;
   }
   #button5{
    background-color: rgb(0,0,0);
    box-shadow: 25px 25px 25px brgb(0, 217, 255);;
    
  
   }
   
  </style>
</head>
<body style="background-color:  grey"><center>
   <h1>LIST OF YOUR DOCUMENT</h1><br>
   <hr></hr>
  <form method="POST" action="delete.php">
    <fieldset style="width: 60%;background-color:grey;border-radius: 35px; border:solid 4px black;">
      <legend  style="background-color:bisque;border-radius: 3px;border:solid 4px black;">fill to delete all</legend>
    <input type="number" name="id" placeholder="ingiza id namba iliyopo home page katika maandishi yanayopita" style="width: 50%; height: 30px;  border-radius: 10px;" required><br>
    <button type="submit"  style="background-color: red;">submit</button><br><br>
    </fieldset>
  </form>
  <hr></hr>
</center>
</body>
</html>