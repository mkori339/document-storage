<?php
session_start();
include("connection.php");
if(isset($_SESSION['id']) ){
    $id=$_SESSION['id'];
  
  if($_SERVER['REQUEST_METHOD']=="POST")
{ 
  $name=$_POST['name'];
   $pass=$_POST['pass'];
   $sql="UPDATE hafidhi  SET name='$name', pasward='$pass' WHERE id='$id'";
 $check=mysqli_query($con,$sql);
 if($check){
    header("location:index.php");
    echo'<script>
    window.alert("updated sucsessfull");
     </script>';
 }
 else{
    echo("something went wrong");
}
}
 }
 else
 header("location:login.php");
?>
<!DOCTYPE html>

<html>
<head>
  <meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
  <title>hafidhi website</title>

<style>
  #body3{

background-image:url("kk.jpg");
background-position:center;
background-attachment:fixed;
background-size:cover;
background-repeat:no-repeat;
  
  }
  </style>
</head>
<body  id="body3" style=" background-color: rgb(0, 217, 255)"><center>
<div style="border-radius: 10px;background-color:grey;border:solid 20px  rgb(11, 11, 88);height:80%; width:80%;">
   <h1>well come to update your deatails</h1><br>
   <hr></hr>
  <form method="POST" action="update.php">
    <fieldset style="width: 80%;background-color:rgb(168, 199, 250);">
      <legend style="background-color:rgb(168, 199, 250);border-radius: 35px;">update person information</legend>
    <input type="text" name="name" placeholder="jina la kwanza"   style="width: 50%; height: 30px;  border-radius: 10px;" required><br>
    <input type="password" name="pass" placeholder="your passward"  style="width: 50%; height: 30px;  border-radius: 10px;" required><br><br>
    <button type="submit" style="background-color: red;">submit</button><br><br>
    </fieldset>
  </form>
  <hr></hr>
</div>
</center>
</body>
</html>